package com.bvcott.bubank.model.transaction;

public enum TransactionType {
    DEPOSIT,
    WITHDRAWAL,
    TRANSFER,
    MERCHANT
}
