package com.bvcott.bubank.model.transaction.transfer;

public enum TransferDirection {
    SENDER,
    RECEIVER
}
