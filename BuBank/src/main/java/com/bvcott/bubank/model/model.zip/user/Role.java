package com.bvcott.bubank.model.user;

public enum Role {
    ROLE_CUSTOMER,
    ROLE_ADMIN
}
