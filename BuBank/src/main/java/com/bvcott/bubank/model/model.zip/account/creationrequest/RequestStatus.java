package com.bvcott.bubank.model.account.creationrequest;

public enum RequestStatus {
    PENDING,
    APPROVED,
    REJECTED
}
