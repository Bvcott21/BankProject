package com.bvcott.bubank.model.transaction.merchant;

public enum MerchantCategory {
    RETAIL,
    GROCERIES,
    UTILITIES,
    TRANSPORT,
    ENTERTAINMENT,
    OTHER
}
